package mic3;

public class RegisterRequest {
	// Identification number of an architect
	private int id;

	// Getter for id
	public int getId() {
		return id;
	}

	// Setter for id
	public void setId(int id) {
		this.id = id;
	}
}
