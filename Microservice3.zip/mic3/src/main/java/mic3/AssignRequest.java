package mic3;

import mic3.part4.ProjectNumber;

public class AssignRequest {
	// Identification number of an architect
	private int id;

	// Project number enumeration object
	private ProjectNumber projectNumber;

	// Getter for id
	public int getId() {
		return id;
	}

	// Setter for id
	public void setId(int id) {
		this.id = id;
	}

	// Getter for projectNumber
	public ProjectNumber getProjectNumber() {
		return projectNumber;
	}

	// Setter for projectNumber
	public void setProjectNumber(ProjectNumber projectNumber) {
		this.projectNumber = projectNumber;
	}
}
