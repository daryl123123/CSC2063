package mic3;

public class Response {

	// Response code of an operation
	private int code;
	
	// Getter for code
	public int getCode() {
		return code;
	}
	
	// Setter for code
	public void setCode(int code) {
		this.code = code;
	}
}
