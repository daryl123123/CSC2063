package mic3;

import mic3.part4.ProjectNumber;

public class CheckRequest {
	// Object of the ProjectNumber enumeration
	private ProjectNumber projectNumber;

	// Getter for projectNumber
	public ProjectNumber getProjectNumber() {
		return projectNumber;
	}

	// Setter for projectNumber
	public void setProjectNumber(ProjectNumber projectNumber) {
		this.projectNumber = projectNumber;
	}
}
