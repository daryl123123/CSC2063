package mic3.part4;

public enum ProjectNumber {
	P_1, 
	P_2,
	P_3,
	P_4,
	P_5
}
