package mic3.part2;

import java.util.ArrayList;

import mic3.part4.Project;
import mic3.part4.ProjectNumber;

public class Architect {
	private int id;
	private ArrayList<Project> projects;
	private ArrayList<ProjectNumber> projectNumbers;

	// Getter for id
	public int getId() {
		return id;
	}

	// Setter for id
	public void setId(int id) {
		this.id = id;
	}

	// Getter for projects
	public ArrayList<Project> getProjects() {
		return projects;
	}

	// Setter for projects
	public void setProjects(ArrayList<Project> projects) {
		this.projects = projects;
	}

	// Getter for projectNumbers
	public ArrayList<ProjectNumber> getProjectNumber() {
		return projectNumbers;
	}

	// Setter for projectNumbers
	public void setProjectNumber(ArrayList<ProjectNumber> projectNumbers) {
		this.projectNumbers = projectNumbers;
	}

}
