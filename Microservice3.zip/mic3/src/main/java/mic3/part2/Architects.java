package mic3.part2;

import java.util.ArrayList;

public class Architects {
	private ArrayList<Architect> architects = new ArrayList<>();

	// Getter for architects
	public ArrayList<Architect> getArchitects() {
		return architects;
	}

	// Setter for architects
	public void setArchitects(ArrayList<Architect> architects) {
		this.architects = architects;
	}
}
