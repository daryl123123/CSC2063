package mic3;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/architechts")
public class ServiceEndpoints {

	@POST
	@Path("/register")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response register(RegisterRequest c) {
		Mic3Service service = new Mic3Service();
		return service.register(c);

	}

	@POST
	@Path("/assign")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response assign(AssignRequest c) {
		Mic3Service service = new Mic3Service();
		return service.assign(c);

	}

	@POST
	@Path("/check")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response check(CheckRequest c) {
		Mic3Service service = new Mic3Service();
		return service.check(c);

	}

}
