package mic3;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import com.fasterxml.jackson.databind.ObjectMapper;
import mic3.part4.Project;
import mic3.part2.Architect;
import mic3.part2.Architects;

public class Mic3Service {

	public static final String ARCHITECTS_FILE_PATH = "src/main/resources/Architects.json";

	public Response register(RegisterRequest c) {

		Response response = new Response();

		// Add null check for input
		if (c == null) {
			response.setCode(-1); // Error code for null input
			return response;
		}

		Architects architects = null;

		try {
			architects = deserialize();
		} catch (Exception e) {
			e.printStackTrace();
			response.setCode(-1); // Exception was caught
			return response;
		}

		for (Architect architect : architects.getArchitects()) {
			if (architect.getId() == c.getId()) {
				response.setCode(4); // The user already exists in the system
				return response;
			}
		}

		Architect newArchitect = new Architect();
		newArchitect.setId(c.getId());
		newArchitect.setProjectNumber(new ArrayList<>());
		newArchitect.setProjects(new ArrayList<>());

		architects.getArchitects().add(newArchitect);

		try {
			serialize(architects);

		} catch (Exception e) {
			e.printStackTrace();
			response.setCode(-1); // Exception was caught
			return response;
		}

		response.setCode(0); // Successful execution
		return response;
	}

	private Architects deserialize() throws Exception {
		ObjectMapper objectMapper = new ObjectMapper();

		Architects architects;

		try {
			File file = new File(ARCHITECTS_FILE_PATH);
			if (file.exists()) {
				architects = objectMapper.readValue(file, Architects.class);
				// Ensure the list is initialized
				if (architects.getArchitects() == null) {
					architects.setArchitects(new ArrayList<>());
				}
			} else {
				architects = new Architects();
			}

		} catch (IOException e) {
			e.printStackTrace();
			throw new Exception("Failed to read Architects.json file!");
		}
		return architects;

	}

	private void serialize(Architects architects) throws Exception {
		ObjectMapper objectMapper = new ObjectMapper();

		try {
			objectMapper.writeValue(new File(ARCHITECTS_FILE_PATH), architects);
		} catch (IOException e) {
			e.printStackTrace();
			throw new Exception("Failed to write to Architects.json file!");
		}

	}

	public Response assign(AssignRequest c) {
		Response response = new Response();

		// Add null check for input
		if (c == null) {
			response.setCode(-1); // Error code for null input
			return response;
		}

		// Check if file exists
		File file = new File(ARCHITECTS_FILE_PATH);
		if (!file.exists()) {
			response.setCode(5); // The file does not exist in the system
			return response;
		}

		// Deserialize the json file content into an Architects object
		Architects architects;
		try {
			architects = deserialize();
		} catch (Exception e) {
			e.printStackTrace();
			response.setCode(-1); // Exception was caught
			return response;
		}

		Architect targetArchitect = null;
		for (Architect arc : architects.getArchitects()) {
			if (arc.getId() == c.getId()) {
				targetArchitect = arc;
				break;
			}
		}
		if (targetArchitect == null) {
			response.setCode(6); // The architect does not exist in the file
			return response;
		}

		// Check if project number has already been assigned
		if (targetArchitect.getProjectNumber() != null
				&& targetArchitect.getProjectNumber().contains(c.getProjectNumber())) {
			response.setCode(7); // Architect is already associated with this project number
			return response;
		}

		// Check if architect has reached max number of projects (5 per architect)
		if (targetArchitect.getProjects() != null && targetArchitect.getProjects().size() >= 5) {
			response.setCode(3); // Architects capacity is full
			return response;
		}

		// Initialize lists if they are null
		if (targetArchitect.getProjects() == null) {
			targetArchitect.setProjects(new ArrayList<>());
		}
		if (targetArchitect.getProjectNumber() == null) {
			targetArchitect.setProjectNumber(new ArrayList<>());
		}

		// Create a new Project and add it along with project number
		Project newProject = new Project();
		newProject.setProjectNumber(c.getProjectNumber()); // Set project number

		targetArchitect.getProjects().add(newProject);
		targetArchitect.getProjectNumber().add(c.getProjectNumber());

		// Serialize updated Architects object back to json file
		try {
			serialize(architects);
		} catch (Exception e) {
			e.printStackTrace();
			response.setCode(-1);
			return response;
		}

		// Return success code
		response.setCode(0);
		return response;
	}

	public Response check(CheckRequest c) {
		Response response = new Response();

		// Check if file exists
		File file = new File(ARCHITECTS_FILE_PATH);
		if (!file.exists()) {
			response.setCode(5); // File does not exist in the system
			return response;
		}

		// Deserialize json file into an Architects object
		Architects architects;
		try {
			architects = deserialize();
		} catch (Exception e) {
			e.printStackTrace();
			response.setCode(-1); // Exception was caught
			return response;
		}

		for (Architect arc : architects.getArchitects()) {
			if (arc.getProjectNumber() != null && arc.getProjectNumber().contains(c.getProjectNumber())) {
				response.setCode(0); // The project has been assigned to an existing architect
				return response;
			}
		}
		response.setCode(8); // The project has not been assigned to an architect
		return response;
	}

}
