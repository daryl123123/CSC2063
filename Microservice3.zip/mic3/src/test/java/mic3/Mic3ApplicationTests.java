package mic3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mic3ApplicationTests {

	@Test
	void contextLoads() throws Exception {
		// Create an instance of ServiceEndpointTests
		ServiceEndpointTests tests = new ServiceEndpointTests();

		// Invoke test methods
		tests.registerNullPostRequest();
		tests.assignNotExistingFilePostRequest();
		tests.registerNotExistingArchitectPostRequest(); 
		tests.registerExistingArchitectPostRequest();
		tests.assignNullPostRequest(); 
		tests.assignNotExistingProjectPostRequest(); 
		tests.assignNotExistingArchitectPostRequest();
		tests.assignExistingProjectPostRequest(); 
		tests.checkNotExistingProjectPostRequest(); 
		tests.checkExistingProjectPostRequest();
	}

}
