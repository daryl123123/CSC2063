package mic3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import java.io.File;
import mic3.part4.ProjectNumber;

public class ServiceEndpointTests {

	// Delete json file before running tests
	public ServiceEndpointTests() {
		File file = new File(Mic3Service.ARCHITECTS_FILE_PATH);
		if (file.exists()) {
			file.delete();
		}
	}

	public void registerNullPostRequest() {
		// Create an instance of Mic3Service
		Mic3Service service = new Mic3Service();

		// Submit a null input to the register method
		Response response = service.register(null);

		// Null input should return
		int expectedResponse = -1;

		// Check if the response matches
		assertEquals(expectedResponse, response.getCode(), "Response code does not match!");
	}

	public void assignNotExistingFilePostRequest() {
		// Create an instance of Mic3Service
		Mic3Service service = new Mic3Service();

		// Create an assign request with id 1 and project number P_1
		AssignRequest request = new AssignRequest();
		request.setId(1);
		request.setProjectNumber(ProjectNumber.P_1);

		// Ensure file doesn't exist for test if it exists delete
		File file = new File("src/main/resources/Architects.json");
		if (file.exists()) {
			file.delete();
		}

		// Submit request to assign method
		Response response = service.assign(request);

		// Expected response code should be 5 for file doesn't exist
		int expectedResponse = 5;

		// Check if expected response matches
		assertEquals(expectedResponse, response.getCode(), "Response does not match!");
	}

	public void registerNotExistingArchitectPostRequest() {
		// Create an instance of Mic3Service
		Mic3Service service = new Mic3Service();

		// Create a register request with id 1
		RegisterRequest request = new RegisterRequest();
		request.setId(1);

		// Submit request to register method
		Response response = service.register(request);

		// Expected response when registering a new engineer should be 0 for success
		int expectedResponse = 0;

		// Check if expected response matches
		assertEquals(expectedResponse, response.getCode(), "Response code does not match!");
	}

	public void registerExistingArchitectPostRequest() {
		// Create an instance of Mic3Service
		Mic3Service service = new Mic3Service();

		// Create a register request with id 1 same as last test
		RegisterRequest request = new RegisterRequest();
		request.setId(1);

		// Submit request to register method
		Response response = service.register(request);

		// Expected response code when registering an engineer that already exists
		// should be 4
		int expectedResponse = 4;

		// Check if expected response matches
		assertEquals(expectedResponse, response.getCode(), "Response does not match!");
	}

	public void assignNullPostRequest() {
		// Create an instance of Mic3Service
		Mic3Service service = new Mic3Service();

		// Submit a null input
		Response response = service.assign(null);

		// Expected response code -1
		int expectedResponse = -1;

		// Check if expected response matches
		assertEquals(expectedResponse, response.getCode(), "Response does not match!");
	}

	public void assignNotExistingProjectPostRequest() {
		// Create an instance of Mic3Service
		Mic3Service service = new Mic3Service();

		// Create an assign request with id 1 and project number P_1
		AssignRequest assign = new AssignRequest();
		assign.setId(1);
		assign.setProjectNumber(ProjectNumber.P_1);

		// Submit the request to assign method
		Response response = service.assign(assign);

		// Expected response code should be 0 success
		int expectedResponse = 0;

		// Check if expected response matches
		assertEquals(expectedResponse, response.getCode(), "Response does not match!");
	}

	public void assignNotExistingArchitectPostRequest() {
		// Create an instance of Mic3Service
		Mic3Service service = new Mic3Service();

		// Create an assign request with id 100 and project number P_1
		AssignRequest assign = new AssignRequest();
		assign.setId(100);
		assign.setProjectNumber(ProjectNumber.P_1);

		// Submit the request to assign method
		Response response = service.assign(assign);

		// Expected response code should be 6 user does not exist
		int expectedResponse = 6;

		// Check if expected response matches
		assertEquals(expectedResponse, response.getCode(), "Response does not match!");
	}

	public void assignExistingProjectPostRequest() {
		// Create an instance of Mic3Service
		Mic3Service service = new Mic3Service();

		// Create an assign request with id 1 and project number P_1
		AssignRequest assign = new AssignRequest();
		assign.setId(1);
		assign.setProjectNumber(ProjectNumber.P_1);

		// Submit the request to assign method
		Response response = service.assign(assign);

		// Expected response code should be 7 project already assigned
		int expectedResponse = 7;

		// Check if expected response matches
		assertEquals(expectedResponse, response.getCode(), "Response does not match!");

	}

	public void checkNotExistingProjectPostRequest() {
		// Create an instance of Mic3Service
		Mic3Service service = new Mic3Service();

		// Create a check request with project number P_5
		CheckRequest check = new CheckRequest();
		check.setProjectNumber(ProjectNumber.P_5);

		// Call check method
		Response response = service.check(check);

		// Expected Response project not assigned to an architect
		int expectedResponse = 8;

		// Check if expected response matches
		assertEquals(expectedResponse, response.getCode(), "Response does not match!");
	}

	public void checkExistingProjectPostRequest() {
		// Create an instance of Mic3Service
		Mic3Service service = new Mic3Service();

		// Create a check request with project number P_5
		CheckRequest check = new CheckRequest();
		check.setProjectNumber(ProjectNumber.P_1);

		// Call check method
		Response response = service.check(check);

		// Expected Response 0 success as its assigned to another architect
		int expectedResponse = 0;

		// Check if expected response matches
		assertEquals(expectedResponse, response.getCode(), "Response does not match!");
	}

}
