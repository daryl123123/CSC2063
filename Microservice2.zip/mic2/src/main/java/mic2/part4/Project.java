package mic2.part4;

public class Project {

	private ProjectNumber projectNumber;

	// Getter for projectNumber
	public ProjectNumber getProjectNumber() {
		return projectNumber;
	}

	// Setter for projectNumber
	public void setProjectNumber(ProjectNumber projectNumber) {
		this.projectNumber = projectNumber;
	}

}