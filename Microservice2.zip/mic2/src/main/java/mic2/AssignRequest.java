package mic2;

import mic2.part4.ProjectNumber;

public class AssignRequest {

	// identification number of an engineer
	private int id;

	// object projectNumber of the enumeration ProjectNumber
	ProjectNumber projectNumber;

	// Getter for id
	public int getId() {
		return id;
	}

	// Setter for id
	public void setId(int id) {
		this.id = id;
	}

	// Getter for projectNumber
	public ProjectNumber getProjectNumber() {
		return projectNumber;
	}

	// Setter for projectNumber
	public void setProjectNumber(ProjectNumber projectNumber) {
		this.projectNumber = projectNumber;
	}
}
