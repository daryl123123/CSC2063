package mic2;

public class Response {

	// Response code for execution of the operation
	private int code;

	// Getter for code
	public int getCode() {
		return code;
	}

	// Setter for code
	public void setCode(int code) {
		this.code = code;
	}
}
