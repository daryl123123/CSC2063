package mic2;

import jakarta.ws.rs.Path;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/engineers")
public class ServiceEndpoints {
	
	@POST
    @Path("/register")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
	public Response register(RegisterRequest c) {
		 Mic2Service service = new Mic2Service();
		 return service.register(c);
	}

	@POST
    @Path("/assign")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
	public Response assign(AssignRequest c) {
		Mic2Service service = new Mic2Service();
		 return service.assign(c);
	}
}
