package mic2;

import mic2.part3.Engineers;
import mic2.part4.Project;

import java.io.IOException;
import java.util.ArrayList;

import com.fasterxml.jackson.databind.ObjectMapper;
import mic2.part3.Engineer;
import java.io.File;

public class Mic2Service {

	public static final String ENGINEERS_FILE_PATH = "src/main/resources/Engineers.json";

	public Response assign(AssignRequest c) {
		Response response = new Response();

		// Add null check for input
		if (c == null) {
			response.setCode(-1); // Error code for null input
			return response;
		}

		// Check if file exists
		File file = new File(ENGINEERS_FILE_PATH);
		if (!file.exists()) {
			response.setCode(5); // The file does not exist in the system
			return response;
		}

		// Deserialize the json file content into an Engineers object
		Engineers engineers;
		try {
			engineers = deserialize();
		} catch (Exception e) {
			e.printStackTrace();
			response.setCode(-1); // Exception was caught
			return response;
		}

		Engineer targetEngineer = null;
		for (Engineer eng : engineers.getEngineers()) {
			if (eng.getId() == c.getId()) {
				targetEngineer = eng;
				break;
			}
		}
		if (targetEngineer == null) {
			response.setCode(6); // The engineer does not exist in the file
			return response;
		}

		// Check if project number has already been assigned
		if (targetEngineer.getProjectNumber() != null
				&& targetEngineer.getProjectNumber().contains(c.getProjectNumber())) {
			response.setCode(7); // Engineer is already associated with this project number
			return response;
		}

		// Check if engineer has reached max number of projects (5 per engineer)
		if (targetEngineer.getProjects() != null && targetEngineer.getProjects().size() >= 5) {
			response.setCode(3); // Engineers capacity is full
			return response;
		}

		// Initialize lists if they are null
		if (targetEngineer.getProjects() == null) {
			targetEngineer.setProjects(new ArrayList<>());
		}
		if (targetEngineer.getProjectNumber() == null) {
			targetEngineer.setProjectNumber(new ArrayList<>());
		}

		// Create a new Project and add it along with project number
		Project newProject = new Project();
		newProject.setProjectNumber(c.getProjectNumber()); // Set project number

		targetEngineer.getProjects().add(newProject);
		targetEngineer.getProjectNumber().add(c.getProjectNumber());

		// Serialize updated Engineers object back to json file
		try {
			serialize(engineers);
		} catch (Exception e) {
			e.printStackTrace();
			response.setCode(-1);
			return response;
		}

		// Return success code
		response.setCode(0);
		return response;
	}

	public Response register(RegisterRequest c) {

		Response response = new Response();

		// Add null check for input
		if (c == null) {
			response.setCode(-1); // Error code for null input
			return response;
		}

		Engineers engineers = null;

		try {
			engineers = deserialize();
		} catch (Exception e) {
			e.printStackTrace();
			response.setCode(-1); // Exception was caught
			return response;
		}

		for (Engineer engineer : engineers.getEngineers()) {
			if (engineer.getId() == c.getId()) {
				response.setCode(4); // The user already exists in the system
				return response;
			}
		}

		Engineer newEngineer = new Engineer();
		newEngineer.setId(c.getId());
		newEngineer.setProjectNumber(new ArrayList<>());
		newEngineer.setProjects(new ArrayList<>());

		engineers.getEngineers().add(newEngineer);

		try {
			serialize(engineers);

		} catch (Exception e) {
			e.printStackTrace();
			response.setCode(-1); // Exception was caught
			return response;
		}

		response.setCode(0); // Successful execution
		return response;
	}

	private Engineers deserialize() throws Exception {
		ObjectMapper objectMapper = new ObjectMapper();

		Engineers engineers;

		try {
			File file = new File(ENGINEERS_FILE_PATH);
			if (file.exists()) {
				engineers = objectMapper.readValue(file, Engineers.class);
			} else {
				engineers = new Engineers();
			}

		} catch (IOException e) {
			e.printStackTrace();
			throw new Exception("Failed to read Engineers.json file!");
		}
		return engineers;

	}

	private void serialize(Engineers engineers) throws Exception {
		ObjectMapper objectMapper = new ObjectMapper();

		try {
			objectMapper.writeValue(new File(ENGINEERS_FILE_PATH), engineers);
		} catch (IOException e) {
			e.printStackTrace();
			throw new Exception("Failed to write to Engineers.json file!");
		}

	}

}
