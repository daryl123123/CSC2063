package mic2.part3;

import java.util.ArrayList;

public class Engineers {

	private ArrayList<Engineer> engineers = new ArrayList<Engineer>();
	
	// Getter for engineers
	public ArrayList<Engineer> getEngineers(){
		return engineers;
	}
	
	// Setter for engineers
	public void setEngineers(ArrayList<Engineer> engineers) {
		this.engineers = engineers;
	}
}
