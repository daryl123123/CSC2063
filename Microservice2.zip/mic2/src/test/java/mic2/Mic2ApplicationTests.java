package mic2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mic2ApplicationTests {

	@Test
	void contextLoads() throws Exception {

		// Create an instance of ServiceEndpointTests
		ServiceEndpointTests tests = new ServiceEndpointTests();

		// Invoke test methods
		tests.registerNullPostRequest();
		tests.assignNotExistingFilePostRequest();
		tests.registerNotExistingEngineerPostRequest();
		tests.registerExistingEngineerPostRequest();
		tests.assignNullPostRequest();
		tests.assignNotExistingProjectRequest();
		tests.assignNotExistingEngineerPostRequest();
		tests.assignExistingProjectPostRequest();

	}

}
