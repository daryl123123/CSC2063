package mic2;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

public class HttpPostWrapper {

	Response execute(String uri, String requestBody) {
		Response response = new Response();
		try {
			CloseableHttpClient client = HttpClients.createDefault();
			HttpPost post = new HttpPost(uri);
			StringEntity input = new StringEntity(requestBody);
			input.setContentType("application/json");
			post.setEntity(input);
			CloseableHttpResponse httpResponse = client.execute(post);
			int statusCode = httpResponse.getStatusLine().getStatusCode();
			System.out.println("Status code of POST request = " + statusCode);

			if (statusCode != 200) {
				response.setCode(-1); // Code-1 means error
				return response;
			}
			httpResponse.close();
			client.close();

		} catch (Exception ex) {
			ex.printStackTrace();
			response.setCode(-1);
			return response;
		}
		response.setCode(0); // Code indicates success
		return response;
	}
}
