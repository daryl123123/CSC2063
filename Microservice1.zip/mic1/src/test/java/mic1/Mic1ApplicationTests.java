package mic1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mic1ApplicationTests {

	@Test
	void contextLoads() {
		// Create an instance of ServiceEndpointTests
		ServiceEndpointTests tests = new ServiceEndpointTests();

		// Invoke test methods
		tests.registerNullPostRequest();
		tests.registerUserPostRequest();
		tests.registerManyUserPostRequest();
		tests.registerUserWithoutRolePostRequest();
		tests.assignProjectToArchitectPostRequest();
		tests.assignManyProjectsToArchitectPostRequest();
		tests.assignProjectToEngineerPostRequest();
		tests.assignManyProjectsToEngineerPostRequest();

	}

}
