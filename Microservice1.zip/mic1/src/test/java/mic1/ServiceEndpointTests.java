package mic1;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import mic1.part1.Role;

public class ServiceEndpointTests {
	private ServiceEndpoints service = new ServiceEndpoints();

	public void registerNullPostRequest() {
		BatchRegistrationRequest nullRequest = null;
		Response response = service.batchRegistration(nullRequest);
		assertEquals(-1, response.getCode(), "Expected response code -1 for NULL request");
	}

	public void registerUserPostRequest() {
		BatchRegistrationRequest request = new BatchRegistrationRequest();
		request.setIds(List.of(2, 2));
		request.setRoles(List.of(Role.ARCHITECT, Role.ENGINEER));

		Response response = service.batchRegistration(request);
		assertEquals(0, response.getCode(), "Expected response code 0 for success");
	}

	public void registerManyUserPostRequest() {
		BatchRegistrationRequest request = new BatchRegistrationRequest();
		request.setIds(List.of(3, 4, 3, 4));
		request.setRoles(List.of(Role.ENGINEER, Role.ENGINEER, Role.ARCHITECT, Role.ARCHITECT));

		Response response = service.batchRegistration(request);
		assertEquals(0, response.getCode(), "Expected response code 0 for success");
	}

	public void registerUserWithoutRolePostRequest() {
		BatchRegistrationRequest request = new BatchRegistrationRequest();
		request.setIds(List.of(5, 6));
		request.setRoles(List.of(Role.ENGINEER));

		Response response = service.batchRegistration(request);
		assertEquals(-1, response.getCode(), "Expected response code 2 not provided a role for a new user");
	}

	public void assignProjectToArchitectPostRequest() {
		AssignRequest request = new AssignRequest();
		request.setId(1);
		request.setProjectNumber("P_2");
		Response response = service.assignToArchitect(request);
		assertEquals(0, response.getCode(), "Expected response code 0 for success");
	}

	public void assignManyProjectsToArchitectPostRequest() {
		AssignRequest request = new AssignRequest();
		request.setId(1);
		request.setProjectNumber("P_3");
		Response response = service.assignToArchitect(request);
		assertEquals(7, response.getCode(), "Expected response code 0 for success");
	}

	public void assignProjectToEngineerPostRequest() {
		AssignRequest request = new AssignRequest();
		request.setId(1);
		request.setProjectNumber("P_2");
		Response response = service.assignToEngineer(request);
		assertEquals(0, response.getCode(), "Expected response code 0 for success");
	}

	public void assignManyProjectsToEngineerPostRequest() {
		AssignRequest request = new AssignRequest();
		request.setId(1);
		request.setProjectNumber("P_3");
		Response response = service.assignToEngineer(request);
		assertEquals(7, response.getCode(), "Expected response code 0 for success");
	}
}
