package mic1;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import mic1.part1.Controller;

@Path("/controller")
public class ServiceEndpoints {

	@POST
	@Path("/registerAll")
	@Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
	public Response batchRegistration(BatchRegistrationRequest c) {
		Controller controller = new Controller();
		return controller.batchRegistration(c);
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
	@Path("/assignToEngineer")
	public Response assignToEngineer(AssignRequest c) {
		Controller controller = new Controller();
		
		return controller.assignToEngineer(c);
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
	@Path("/assignToArchitect")
	public Response assignToArchitect(AssignRequest c) {
		Controller controller = new Controller();
		return controller.assignToArchitect(c);
	}
}
