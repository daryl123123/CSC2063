package mic1.part1;

public enum Role {
ENGINEER,
ARCHITECT
}
