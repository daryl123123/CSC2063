package mic1.part1;

import mic1.AssignRequest;
import mic1.BatchRegistrationRequest;
import mic1.Response;

public class Controller {

	public Response batchRegistration(BatchRegistrationRequest c) {
		Response response = new Response();

		if (c.getIds().size() != c.getRoles().size()) {
			response.setCode(2); // Role not provided for all users
			return response;
		}

		for (int i = 0; i < c.getIds().size(); i++) {
			int id = c.getIds().get(i);
			Role role = c.getRoles().get(i);

			if (role == Role.ENGINEER) {
				System.out.println("Registering engineer with ID: " + id);
				response.setCode(4); // User already exists
			} else if (role == Role.ARCHITECT) {
				System.out.println("Registering architect with ID: " + id);
				response.setCode(0); // Success
			} else {
				System.out.println("Unkown role for ID: " + id);
				response.setCode(6); // User does not exist
			}
		}
		return response;
	}

	public Response assignToEngineer(AssignRequest request) {
		Response response = new Response();

		// Simulate checking if the engineer exists
		boolean engineerExists = true; // Replace with actual logic

		if (!engineerExists) {
			response.setCode(6); // User does not exist
		} else {
			System.out.println(
					"Assigning project " + request.getProjectNumber() + " to Engineer with ID: " + request.getId());
			response.setCode(0); // Successful execution
		}

		return response;
	}

	public Response assignToArchitect(AssignRequest request) {
		Response response = new Response();

		// Simulate checking if the architect is already associated with the project
		boolean alreadyAssociated = false; // Replace with actual logic

		if (alreadyAssociated) {
			response.setCode(7); // User already associated with this project
		} else {
			System.out.println(
					"Assigning project " + request.getProjectNumber() + " to Architect with ID: " + request.getId());
			response.setCode(0); // Successful execution
		}

		return response;
	}

}
