package mic1;

import java.util.ArrayList;
import java.util.List;

import mic1.part1.Role;

public class BatchRegistrationRequest {
	private List<Integer> ids = new ArrayList<>();
	private List<Role> roles = new ArrayList<>();
	
	public List<Integer> getIds() {
		return ids;
	}
	
	public void setIds(List<Integer> ids) {
		this.ids = ids;
	}
	
	public List<Role> getRoles() {
		return roles;
	}
	
	public void setRoles(List<Role> roles) {
		this.roles = roles;
	}

}
