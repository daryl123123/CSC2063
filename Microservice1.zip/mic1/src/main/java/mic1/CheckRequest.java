package mic1;

public class CheckRequest {
private String projectNumber;

public String getProjectNumber() {
	return projectNumber;
}

public void setProjectNumber(String projectNumber) {
	this.projectNumber = projectNumber;
}
}
